from ast_node import FuncDef, LambdaExpr, FuncApp, Identifier, IntLit, BoolLit, UnaryOp, BinOp, IfStmt


class BasicEnv:
    def __init__(self, ancestor=None):
        self.ancestor = ancestor
        self.scope = {}

    def lookup(self, identifier):
        if identifier in self.scope:
            return self.scope[identifier]
        elif self.ancestor:
            return self.ancestor.lookup(identifier)
        else:
            raise NameError(f"Undefined variable: {identifier}")

    def define(self, identifier, value):
        self.scope[identifier] = value

    def extend_scope(self, identifiers, values):
        child_env = BasicEnv(self)
        for identifier, value in zip(identifiers, values):
            child_env.define(identifier, value)
        return child_env


class Interpreter:
    def __init__(self, ast):
        self.ast = ast
        self.global_env = BasicEnv()

    def interpret(self):
        print("Starting the interpretation..")
        try:
            result = None
            for node in self.ast:
                try:
                    result = self.evaluate(node, self.global_env)
                    if result is not None:
                        print(result)
                except Exception as e:
                    print(f"Error during the interpretation of node {node}: {e}")
            print("Interpretation is finished..")
            return result
        except Exception as e:
            raise RuntimeError(f"Runtime error during the interpretation: {str(e)}")

    def evaluate(self, node, env):
        if isinstance(node, IntLit):
            return node.val

        elif isinstance(node, Identifier):
            return env.lookup(node.id_name)

        elif isinstance(node, BoolLit):
            return node.val

        elif isinstance(node, BinOp):
            left = self.evaluate(node.left, env)
            if node.op == '&&' and not left:
                return False
            if node.op == '||' and left:
                return True
            right = self.evaluate(node.right, env)
            return self.apply_operator(node.op, left, right)

        elif isinstance(node, FuncDef):
            env.define(node.func_name, (node.parameters, node.func_body, env))
            return None

        elif isinstance(node, UnaryOp):
            value = self.evaluate(node.operand, env)
            return self.apply_unary_operator(node.op, value)

        elif isinstance(node, FuncApp):
            try:
                if isinstance(node.function, str):
                    func = env.lookup(node.function)
                else:
                    func = self.evaluate(node.function, env)

                args = [self.evaluate(arg, env) for arg in node.arguments]

                if isinstance(func, tuple) and len(func) == 3:
                    params, body, closure_env = func

                    if isinstance(params, list):
                        if len(params) != len(args):
                            raise TypeError(f"Expected {len(params)} arguments; received {len(args)}")

                        new_env = closure_env.extend_scope(params, args)
                        return self.evaluate(body, new_env)
                    else:
                        for arg in args:
                            func = self.apply_function(func, [arg])
                        return func

                else:
                    raise TypeError(f"Expected a function or lambda expression; received: {func}")

            except Exception as e:
                raise RuntimeError(f"Failed to apply function: {str(e)}")

        elif isinstance(node, LambdaExpr):
            return node.parameters, node.expr_body, env

        elif isinstance(node, IfStmt):
            try:
                condition_value = self.evaluate(node.cond, env)
                if condition_value:
                    return self.evaluate(node.then_branch, env)
                elif node.else_branch is not None:
                    return self.evaluate(node.else_branch, env)
                return None
            except Exception as e:
                raise RuntimeError(f"Failed to evaluate if-statement: {str(e)}")

        else:
            raise TypeError(f"Unknown node type: {type(node)}")

    def apply_operator(self, op, left, right):
        if op == '+':
            return left + right
        elif op == '-':
            return left - right
        elif op == '*':
            return left * right
        elif op == '/':
            if right == 0:
                raise ZeroDivisionError("Cant divide by zero")
            return left // right
        elif op == '%':
            return left % right
        elif op == '||':
            return left or right
        elif op == '&&':
            return left and right
        elif op == '!=':
            return left != right
        elif op == '==':
            return left == right
        elif op == '<':
            return left < right
        elif op == '>':
            return left > right
        elif op == '>=':
            return left >= right
        elif op == '<=':
            return left <= right
        else:
            raise TypeError(f"Unknown operator: {op}")

    def apply_function(self, func, args):
        param, body, closure_env = func

        if len(args) != 1:
            raise TypeError("Each lambda expression needs to receive exactly one argument.")

        new_env = closure_env.extend_scope([param], args)
        result = self.evaluate(body, new_env)
        return result

    def apply_unary_operator(self, op, value):
        if op == '!':
            return not value
        else:
            raise TypeError(f"Unknown unary operator: {op}")
