class Basic:
    def __init__(self, ancestor=None, bindings=None):
        self.ancestor = ancestor
        self.bindings = bindings if bindings is not None else {}

    def set(self, identifier, value):
        self.bindings[identifier] = value

    def get(self, identifier):
        if identifier in self.bindings:
            return self.bindings[identifier]
        elif self.ancestor:
            return self.ancestor.lookup(identifier)
        else:
            raise NameError(f"Undefined identifier: {identifier}")
