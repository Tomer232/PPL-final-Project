import re


class Lexer:
    def __init__(self, source_code):
        self.source_code = source_code
        self.line_start_pos = 0
        self.current_line = 1
        self.token_list = []

    token_spec = [
        ('INTEGER', r'-?\d+'),  # Int (with negative integers)
        ('BOOL', r'\bTrue\b|\bFalse\b'),  # Boolean
        ('LETTER', r'\b[a-zA-Z_][a-zA-Z_0-9]*\b'),  # Identifiers
        ('BASIC_OP', r'[-+*/%]'),  # Arithmetic Operators
        ('BOOL_OP', r'&&|\|\|'),  # Boolean Operators
        ('COMP_OP', r'==|!=|>=|<=|>|<'),  # Comparison Operators
        ('NOT', r'!'),  # Not Operators
        ('IF', r'\bif\b'),  # If
        ('ELSE', r'\belse\b'),  # Else
        ('LPAREN', r'\('),  # Left '('
        ('RPAREN', r'\)'),  # Right ')'
        ('LBRACE', r'\{'),  # Left '{'
        ('RBRACE', r'\}'),  # Right '}'
        ('ENDLINE', r'\n'),  # Line endings
        ('JUMP', r'[ \t]+'),  # Jump over spaces and tabs
        ('COMMENT', r'#.*'),  # One line comment
        ('INVALID', r'.'),  # Any other char
        ('FUNC', r'\bfunc\b'),  # Function definition word
        ('NAME', r'\bname\b'),  # Function name reserved word
        ('ARGUMENTS', r'\barguments\b'),  # Function arguments reserved word
        ('LAMBADY', r'\bLambady\b'),  # Lambda keyword
        ('COMMA', r','),  # ','
        ('COLON', r':'),  # ':'
        ('DOT', r'\.'),  # '.'
    ]

    # The master regular expression
    token_patterns = [f"(?P<{name}>{pattern})" for name, pattern in token_spec]
    token_regex = '|'.join(token_patterns)

    def tokenize(self):
        for match_obj in re.finditer(self.token_regex, self.source_code):
            token_type = match_obj.lastgroup
            token_value = match_obj.group(token_type)
            column_pos = match_obj.start() - self.line_start_pos

            if token_type == 'INTEGER':
                token_value = int(token_value)
            elif token_type == 'BOOL':
                token_value = (token_value == 'True')
            elif token_type == 'ENDLINE':
                self.line_start_pos = match_obj.end()
                self.current_line += 1
                continue
            elif token_type in {'JUMP', 'COMMENT'}:
                continue
            elif token_type == 'INVALID':
                raise RuntimeError(f'{token_value!r} unexpected on line {self.current_line}')

            self.token_list.append((token_type, token_value, self.current_line, column_pos))

        self.token_list.append(('EOF', 'EOF', self.current_line, column_pos))
        return self.token_list
