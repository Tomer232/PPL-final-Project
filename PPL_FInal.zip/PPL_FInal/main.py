from interpreter import BasicEnv, Interpreter
from lexer import Lexer
from parser import SyntaxParser as Parser
import sys


def run_file(filepath):
    try:
        with open(filepath, 'r') as f:
            script = f.read()
        lexed_tokens = Lexer(script).tokenize()
        parsed_ast = Parser(lexed_tokens).parse()
        exec_context = Interpreter(parsed_ast)
        exec_context.interpret()
    except FileNotFoundError:
        print(f"Error: The file '{filepath}' was not found.")
    except Exception as error:
        print(f"Error executing file '{filepath}': {error}")


def repl():
    print("This is the Interpreter REPL. Type 'exit' to quit.")
    global_context = BasicEnv()

    while True:
        try:
            user_input = input(">>> ")
            if user_input.lower() == "exit":
                break

            lexed_tokens = Lexer(user_input).tokenize()
            parsed_ast = Parser(lexed_tokens).parse()
            exec_context = Interpreter(parsed_ast)
            output = exec_context.interpret()

            if output is not None:
                print(output)

        except Exception as error:
            print(f"Error: {error}")


if __name__ == "__main__":
    try:
        if len(sys.argv) > 1 and sys.argv[1].endswith(".lambda"):
            run_file(sys.argv[1])
        else:
            repl()
    except Exception as error:
        print(f"Unexpected error: {error}")
