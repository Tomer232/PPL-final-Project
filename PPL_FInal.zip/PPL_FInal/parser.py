from ast_node import FuncDef, LambdaExpr, FuncApp, Identifier, IntLit, BoolLit, UnaryOp, BinOp, IfStmt


class GrammarLoader:
    def __init__(self, grammar_file_path):
        self.rules = self.load_grammar(grammar_file_path)

    def load_grammar(self, file_path):
        rules = {}
        with open(file_path, 'r') as file:
            content = file.read()
            lines = content.splitlines()
            current_non_terminal = None
            for line in lines:
                if line.strip() == "":
                    continue
                if "::=" in line:
                    parts = line.split("::=")
                    current_non_terminal = parts[0].strip()
                    rules[current_non_terminal] = [p.strip() for p in parts[1].split("|")]
                else:
                    rules[current_non_terminal].extend([p.strip() for p in line.split("|")])
        return rules


class SyntaxParser:
    def __init__(self, tokens, grammar_file_path=None, debug=False):
        self.tokens = tokens
        self.pos = 0
        self.current_token = self.tokens[self.pos] if tokens else None
        self.debug = debug
        self.rules = GrammarLoader(grammar_file_path).rules if grammar_file_path else None

    def log(self, message):
        if self.debug:
            print(message)

    def raise_syntax_error(self, message):
        line = self.current_token[2]
        col = self.current_token[3]
        raise SyntaxError(
            f"Syntax Error at line {line}, column {col}: {message}. Current token: {self.current_token[0]}")

    def advance_token(self):
        self.log(f"Advancing from {self.current_token}")
        self.pos += 1
        if self.pos < len(self.tokens):
            self.current_token = self.tokens[self.pos]
        else:
            self.current_token = ('EOF', 'EOF', -1, -1)
        self.log(f"Current token is {self.current_token}")

    def match_token(self, token_type):
        self.log(f"Expecting {token_type}, current token: {self.current_token[0]}")
        if self.current_token and self.current_token[0] == token_type:
            self.advance_token()
        else:
            self.raise_syntax_error(f"Expected token {token_type} but got {self.current_token[0]}")

    def parse(self):
        try:
            self.log("Starting to parse..")
            result = self.parse_program()
            self.log("Finishing to parse..")
            return result
        except Exception as e:
            raise RuntimeError(f"Parsing has failed: {str(e)}")

    def parse_statement(self):
        self.log(f"Parsing statement with token: {self.current_token}")
        if self.current_token[0] == 'FUNC':
            return self.parse_function_def()
        elif self.current_token[0] == 'IF':
            return self.parse_if_statement()
        elif self.current_token[0] == 'LPAREN' and self.tokens[self.pos + 1][0] == 'LAMBADY':
            return self.parse_lambda_expr()
        else:
            return self.parse_expression()

    def parse_program(self):
        self.log("Parsing the program...")
        statements = []
        while self.current_token[0] != 'EOF':
            statements.append(self.parse_statement())
        self.log(f"Program parsed with {len(statements)} statement(s).")
        return statements

    def parse_if_statement(self):
        try:
            self.log("Parsing if statement")
            self.match_token('IF')
            condition = self.parse_expression()
            self.match_token('LBRACE')
            consequence = self.parse_expression()
            self.match_token('RBRACE')
            alternative = None
            if self.current_token[0] == 'ELSE':
                self.match_token('ELSE')
                self.match_token('LBRACE')
                alternative = self.parse_expression()
                self.match_token('RBRACE')
            return IfStmt(condition, consequence, alternative)
        except SyntaxError as e:
            self.raise_syntax_error(f"Error parsing if statement: {e}")

    def parse_function_def(self):
        self.log("Parsing the function definition")
        try:
            self.match_token('FUNC')
            self.match_token('LBRACE')
            self.match_token('NAME')
            self.match_token('COLON')
            func_name = self.current_token[1]
            self.match_token('LETTER')
            self.match_token('COMMA')
            self.match_token('ARGUMENTS')
            self.match_token('COLON')
            params = self.parse_params()
            self.match_token('RBRACE')
            if self.current_token[0] == 'IF':
                body = self.parse_if_statement()
            else:
                body = self.parse_expression()
            self.log(f"Function def '{func_name}' with params: {params}, and body: {body}")
            return FuncDef(func_name=func_name, parameters=params, func_body=body)
        except SyntaxError as e:
            self.raise_syntax_error(f"Error parsing function definition: {e}")

    def parse_lambda_expr(self):
        self.log("Parsing the lambda expression")
        self.match_token('LPAREN')
        self.match_token('LAMBADY')
        if self.current_token[0] == 'LETTER':
            params = self.current_token[1]
            self.match_token('LETTER')
            self.match_token('DOT')
        body = self.parse_expression()
        self.match_token('RPAREN')
        lambda_expr = LambdaExpr(parameters=params, expr_body=body)
        self.log(f"Constructed lambda expression: {lambda_expr}")
        if self.current_token[0] == 'LPAREN':
            self.log("Lambda expression is followed by a call, parsing lambda call")
            return self.parse_lambda_call(lambda_expr)
        return lambda_expr

    def parse_function_call(self, func):
        self.log(f"Parsing function call for: {func}")
        func = self.current_token[1]
        self.match_token('LETTER')
        self.match_token('LPAREN')
        args = self.parse_args()
        self.match_token('RPAREN')
        self.log(f"Function call '{func}' with args: {args}")
        return FuncApp(function=func, arguments=args)

    def parse_lambda_call(self, func):
        self.log(f"Parsing lambda call for: {func}")
        self.match_token('LPAREN')
        args = self.parse_args()
        self.match_token('RPAREN')
        self.log(f"lambda call '{func}' with args: {args}")
        return FuncApp(function=func, arguments=args)

    def parse_params(self):
        self.log("Parsing parameters")
        params = []
        self.match_token('LPAREN')
        while self.current_token[0] == 'LETTER' and self.tokens[self.pos + 1][0] == 'COMMA':
            params.append(self.current_token[1])
            self.match_token('LETTER')
            self.match_token('COMMA')
        self.match_token('RPAREN')
        return params

    def parse_args(self):
        self.log("Parsing arguments")
        args = []
        while self.current_token[0] != 'RPAREN':
            args.append(self.parse_expression())
            if self.current_token[0] == 'COMMA':
                self.match_token('COMMA')
            elif self.current_token[0] == 'RPAREN':
                break
            else:
                self.raise_syntax_error(f"Unexpected token in argument list: {self.current_token}")
        return args

    def parse_expression(self):
        self.log(f"Parsing expression with token: {self.current_token}")

        def parse_term():
            if self.current_token[0] == 'NOT':
                op = self.current_token[1]
                self.match_token('NOT')
                expr = self.parse_expression()
                unary_op = UnaryOp(op, expr)
                return unary_op

            if self.current_token[0] == 'LETTER' and self.pos + 1 < len(self.tokens) and self.tokens[self.pos + 1][0] == 'LPAREN':
                return self.parse_function_call(self.current_token[1])

            if self.current_token[0] == 'LPAREN' and self.pos + 1 < len(self.tokens) and self.tokens[self.pos + 1][0] == 'LAMBADY':
                return self.parse_lambda_expr()

            if self.current_token[0] == 'BOOL':
                boolean = BoolLit(self.current_token[1])
                self.match_token('BOOL')
                return boolean

            if self.current_token[0] == 'INTEGER':
                number = IntLit(self.current_token[1])
                self.match_token('INTEGER')
                return number

            if self.current_token[0] == 'LPAREN':
                self.match_token('LPAREN')
                expr = self.parse_expression()
                self.match_token('RPAREN')
                return expr

            if self.current_token[0] == 'LETTER':
                identifier = Identifier(self.current_token[1])
                self.match_token('LETTER')
                return identifier

            self.raise_syntax_error(
                f"Unexpected token: '{self.current_token[0]}' at line {self.current_token[2]}, column {self.current_token[3]}")

        def parse_operation(parse_func, valid_operators):
            left = parse_func()
            while self.current_token[0] in valid_operators:
                op = self.current_token[1]
                self.match_token(self.current_token[0])
                right = parse_func()
                left = BinOp(left, op, right)
            return left

        return parse_operation(parse_term, {'BASIC_OP', 'BOOL_OP', 'COMP_OP'})
